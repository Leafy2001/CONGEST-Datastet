TEST CASE FORMAT:
1. Dimension of the GRID (either 2 or 3)
2. Total UAVs
3. Maximum Number of Vehicles allowed in the region
4. Region Radius
5. Speed of all uavs (space separated)
6. X coordinates of the UAV
7. Y coordinates of the UAV
8. Z coordinates of the UAV
